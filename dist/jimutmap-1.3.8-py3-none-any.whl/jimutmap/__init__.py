

__name__ = "jimutmap"
__version__ = "1.3.8"
__author__ = "Jimut Bahan Pal| jimutbahanpal@yahoo.com"
__release_date__ = '4-May-2019'
from .jimutmap import api
