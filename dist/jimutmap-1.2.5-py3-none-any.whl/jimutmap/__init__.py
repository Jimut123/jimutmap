

__name__ = "jimutmap"
__version__ = "1.2.5"
__author__ = "Jimut Bahan Pal| jimutbahanpal@yahoo.com"
__release_date__ = '4-May-2019'
#__all__ = ['ret_xy_tiles']
from .jimutmap import api
